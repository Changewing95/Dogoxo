function register() { // Create Function register getting the value of input
                      // username and password

var new_user = document.getElementById('username').value
var new_pass = document.getElementById('password').value


if(new_user.match(/[^a-zA-Z0-9\s]+/gi) || new_pass.match(/[^a-zA-Z0-9\s]+/gi)) {
  document.getElementById("loginsuccess").innerHTML = "Error"
  return
}    //validation of the input, if input contains /[^a-zA-Z0-9\s]+/gi then invalid


// I


if(!new_user  || !new_pass) { // if username or password is empty
  var error = document.getElementById("loginsuccess").innerHTML = "Error" // set text error


}
else{

  document.getElementById("loginsuccess").innerHTML = "Success" // else set etxt correct



}

function ifUserExist(accounts, username) { // function ifUserExist
  for(var i in accounts) { // loop through all the accounts
    if(username == accounts[i]['username']) { // if username matches
      return true; //
    }
  }
  return false;
}



var old_data = JSON.parse(localStorage.getItem('accounts')); // get item and parse it into array
if(!old_data) {
  localStorage.setItem('accounts','[]'); // if not the data then set an empty array to localstorage
  old_data = [];

}

if(ifUserExist(old_data,new_user) == true) { //means that if its true, the user in the input value matches
  //the account key [username] change the id of loginsuccess to // error :)
document.getElementById("loginsuccess").innerHTML = "Error"
  return;

}

old_data.push({         //pushing in the the value of variable "new_user" and "new_pass" to value username and password
  "username": new_user,
  "password": new_pass
});


localStorage.setItem('accounts', JSON.stringify(old_data));
//store a entire javascript object// change it to string
//cause localstorage only can set string
// set the new user/ key accounts to the localstorage
// stringify is to convert an array to json data










}
