$(document).ready(function(){
  var cartItem = localStorage.getItem("cart");
  if(!cartItem) {
    cartItem = "[]"

    localStorage.setItem('cart','[]');



  }
  cartItem = JSON.parse(cartItem);

  for(var i in cartItem) {
    var container = $('<div class="col-12"> </div>')
    container.text(cartItem[i]['name'])
    $('#cart').append(container)
  }

})
