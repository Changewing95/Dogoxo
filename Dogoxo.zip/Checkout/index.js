$(document).ready(function() {
	$(".invoice").hide();
	$("#error").hide();

	$("#submit").on("click", function() {
		var name  = $("#name").val();
		var email = $("#email").val();

		var card = $("#credit_card").val();
		var exp = $("#exp").val();
		var cvv = $("#cvv").val();

		if(name && email && card && exp && cvv) {
			if(valid_credit_card(card)) {
				console.log("validation passes");
				$(".checkout").fadeOut(400);
				$(".invoice").fadeIn(400);

				$("#inv_id").text(Math.random()* 666666);
				$("#inv_name").text(name);
				$("#inv_email").text(email);
				$("#inv_cc").text(card.substr(0, 8) + "********");
				$("#inv_exp").text(exp);
				$("#inv_cvv").text(cvv);
			} else {
				console.log("stop stealing credit card");
				$("#error")
				.text("Invalid Credit Card")
				.fadeIn(400);
			}
		} else {
			$("#error")
			.text("Please fill in the blanks")
			.fadeIn(400);
		}

	});
});

function valid_credit_card(value) {
  // Accept only digits, dashes or spaces
	if (/[^0-9-\s]+/.test(value)) return false;

	// The Luhn Algorithm. It's so pretty.
	let nCheck = 0, bEven = false;
	value = value.replace(/\D/g, "");

	for (var n = value.length - 1; n >= 0; n--) {
		var cDigit = value.charAt(n), nDigit = parseInt(cDigit, 10);

		if (bEven && (nDigit *= 2) > 9) nDigit -= 9;

		nCheck += nDigit;
		bEven = !bEven;
	}

	return (nCheck % 10) == 0;
}