function login() {  // function login

    var username1 = document.getElementById('username_input').value; // get login username
    var password2 = document.getElementById('password_input').value; // get login password


    var accounts = localStorage.getItem('accounts'); //get  the key account database

  try {
    accounts = JSON.parse(accounts); // parse db string to array //
    if(ifUserExist(accounts,username1,password2) == true) { // check user exists
      alert("login");
      localStorage.setItem("loggedin",true); // set flag logged in to true //easier to check for error
      localStorage.setItem("username",username1); // set username to username //set value
      window.location.href = "/HomePage/" // redirect to home

    }
  else {
    alert("Error") // error messgae
  }

  }

  catch(e) {
    console.log(e); // catch any errors

  }

}



function ifUserExist(accounts, username,password) { // function user ecists
  for(var i in accounts) { // loop through all the accounts
    if(username == accounts[i]['username'] && password == accounts[i]['password']) {// if username matches
      return true;
    }
  }
  return false;
}

$(document).ready(function() {
  var user = localStorage.getItem("username");
  if(user) {
    $("#btn_user, #btn_user2").hide();
    $(".profile").fadeIn(200);
    $(".profileid").text(user);
  }
});
