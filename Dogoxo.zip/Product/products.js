var products = {
  123: {
    name : "Dog Food#1",
    desc : "Good Dog Food",
    img : "Product1.jpg.png",
    price : 10
  },
  124: {
    name : "Dog Food#2",
    desc : "Good Dog Food #2.",
    img : "Product2.png",
    price : 20
  },
  125: {
    name : "Dog Food#3",
    desc : "Good Dog Food #3.",
    img : "Product3.png",
    price : 15
  },
  126: {
    name : "Dog Food #4",
    desc : "Very good dog food ",
    img : "Product4.png",
    price : 20
  }
};

$(document).ready(function() {
  var user = localStorage.getItem("username");   // take the username value
  // if user is logged in then it will execute the code below // if this is true then it will launch this code
  if(user) {
    $("#btn_user, #btn_user2").hide();
    $(".profile").fadeIn(200);
    $(".profileid").text(user);
  }
});