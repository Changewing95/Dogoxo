



know = {
  "Hi":"Hi There This is A Chat Bot!",
  "help":"Do You need Any help?",
  "yes": "Oh I See Wait a while!"
};

function sendReply(data) {
  var correct = document.getElementById('chat-append').innerHTML += know[data] + "<br>"

}


function talk() {
  var user = document.getElementById("userBox").value;
  document.getElementById("userBox").value = "";
  document.getElementById("chat-append").innerHTML += user + "<br>"

  if(user in know) {
      setTimeout(function() { sendReply(user) }, 2000)
  }
  else {
    var wrong = document.getElementById('chat-append').innerHTML += "Please Wait A While <br>";
  }

}
//change button and get the potrait
$(document).ready(function() {
  var user = localStorage.getItem("username");   // take the username value
  // if user is logged in then it will execute the code below // if this is true then it will launch this code
  if(user) {
    $("#btn_user, #btn_user2").hide();
    $(".profile").fadeIn(200);
    $(".profileid").text(user);
  }
});




function calculateDogAge() {
  var myAge= document.getElementById('years').value;
  var dogAge = myAge * 7;

  document.getElementById('wynik').innerHTML= dogAge + ' years old in human years.';

}
